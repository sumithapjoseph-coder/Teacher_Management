﻿using Microsoft.AspNetCore.Mvc;
using TeacherManagementApp.Models;
using TeacherManagementApp.Services;

namespace TeacherManagementApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly AuthService _authService;

        public AccountController(AuthService authService)
        {
            _authService = authService;
        }

        // ---------------- LOGIN ----------------

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginDto model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var result = await _authService.Login(model);

            if (result != null)
            {
                return RedirectToAction("Index", "Teachers");
            }

            ViewBag.Error = "Invalid Login";
            return View(model);
        }

        // ---------------- REGISTER ----------------

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterDto model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var result = await _authService.Register(model);

            if (result != null)
            {
                return RedirectToAction("Login");
            }

            ViewBag.Error = "Registration Failed";
            return View(model);
        }

        // ---------------- LOGOUT ----------------

        public IActionResult Logout()
        {
            return RedirectToAction("Login");
        }
    }
}