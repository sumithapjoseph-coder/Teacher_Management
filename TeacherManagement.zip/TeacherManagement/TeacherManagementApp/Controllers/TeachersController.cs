﻿using Microsoft.AspNetCore.Mvc;
using TeacherManagementApp.Models;
using TeacherManagementApp.Services;

namespace TeacherManagementApp.Controllers
{
    public class TeachersController : Controller
    {
        private readonly TeacherService _teacherService;

        public TeachersController(TeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        // GET: Teachers
        public async Task<IActionResult> Index()
        {
            var teachers = await _teacherService.GetTeachers();
            return View(teachers);
        }

        // GET: Teachers/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var teacher = await _teacherService.GetTeacherById(id);
            return View(teacher);
        }

        // GET: Teachers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Teachers/Create
        [HttpPost]
        public async Task<IActionResult> Create(Teacher teacher)
        {
            await _teacherService.AddTeacher(teacher);
            return RedirectToAction("Index");
        }

        // GET: Teachers/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var teacher = await _teacherService.GetTeacherById(id);
            return View(teacher);
        }

        // POST: Teachers/Edit
        [HttpPost]
        public async Task<IActionResult> Edit(int id, Teacher teacher)
        {
            await _teacherService.UpdateTeacher(id, teacher);
            return RedirectToAction("Index");
        }

        // GET: Teachers/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            await _teacherService.DeleteTeacher(id);
            return RedirectToAction("Index");
        }
    }
}