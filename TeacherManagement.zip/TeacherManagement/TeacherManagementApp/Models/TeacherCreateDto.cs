﻿namespace TeacherManagementApp.Models
{
    public class TeacherCreateDto
    {
        public string Name { get; set; }

        public string Subject { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Address { get; set; }

        public int Age { get; set; }
    }
}
