using TeacherManagementApp.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddHttpClient<AuthService>(client =>
{
    client.BaseAddress = new Uri("http://demoapimachinetest.ortezerp.in/");
});

builder.Services.AddHttpClient<TeacherService>(client =>
{
    client.BaseAddress = new Uri("http://demoapimachinetest.ortezerp.in/");
});

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();