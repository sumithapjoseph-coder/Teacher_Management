﻿using System.Text;
using System.Text.Json;
using TeacherManagementApp.Models;

namespace TeacherManagementApp.Services
{
    public class AuthService
    {
        private readonly HttpClient _httpClient;

        public AuthService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // LOGIN API
        public async Task<AuthResponseDto> Login(LoginDto loginDto)
        {
            var json = JsonSerializer.Serialize(loginDto);

            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("api/Auth/login", content);

            if (!response.IsSuccessStatusCode)
                return null;

            var data = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<AuthResponseDto>(data,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        // REGISTER API
        public async Task<AuthResponseDto> Register(RegisterDto registerDto)
        {
            var json = JsonSerializer.Serialize(registerDto);

            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("api/Auth/register", content);

            if (!response.IsSuccessStatusCode)
                return null;

            var data = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<AuthResponseDto>(data,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
    }
}