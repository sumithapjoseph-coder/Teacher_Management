﻿using System.Text;
using System.Text.Json;
using TeacherManagementApp.Models;

namespace TeacherManagementApp.Services
{
    public class TeacherService
    {
        private readonly HttpClient _httpClient;

        public TeacherService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Teacher>> GetTeachers()
        {
            var response = await _httpClient.GetAsync("api/Teachers");
            var data = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<List<Teacher>>(data,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<Teacher> GetTeacherById(int id)
        {
            var response = await _httpClient.GetAsync($"api/Teachers/{id}");
            var data = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<Teacher>(data,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task AddTeacher(Teacher teacher)
        {
            var dto = new TeacherCreateDto
            {
                Name = teacher.Name,
                Subject = teacher.Subject,
                Email = teacher.Email,
                Phone = teacher.Phone,
                Address = teacher.Address,
                Age = teacher.Age
            };

            var json = JsonSerializer.Serialize(dto);

            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("api/Teachers", content);

            response.EnsureSuccessStatusCode();
        }

        public async Task UpdateTeacher(int id, Teacher teacher)
        {
            var json = JsonSerializer.Serialize(teacher);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            await _httpClient.PutAsync($"api/Teachers/{id}", content);
        }

        public async Task DeleteTeacher(int id)
        {
            await _httpClient.DeleteAsync($"api/Teachers/{id}");
        }
    }
}